<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard PC'); ?> | KOIN NU - LAZISNU</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('logo_lazisnu_lmg.png')); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('logo_lazisnu_lmg.png')); ?>">

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Theme style (AdminLTE 3.2) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">

    <style>
        :root {
            --nu-green: #0a6b38;
            --nu-dark-green: #064d27;
            --nu-gold: #cba052;
        }
        .main-header.navbar-nu {
            background-color: var(--nu-green);
            color: #ffffff;
        }
        .main-header.navbar-nu .nav-link {
            color: rgba(255, 255, 255, 0.9) !important;
        }
        .brand-link.nu-brand {
            background-color: var(--nu-dark-green) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .sidebar-dark-success .nav-sidebar>.nav-item>.nav-link.active {
            background-color: var(--nu-green) !important;
        }
    </style>
    <!-- Frontend Route Guard & Client Auth State Check -->
    <script>
        (function() {
            <?php if(auth()->guard()->guest()): ?>
                window.location.replace("<?php echo e(route('login')); ?>?expired=1");
                return;
            <?php endif; ?>

            try {
                sessionStorage.setItem('koinnu_auth_active', '1');
                sessionStorage.setItem('koinnu_user_id', '<?php echo e(Auth::id()); ?>');
                sessionStorage.setItem('koinnu_user_role', '<?php echo e(Auth::user()?->role?->name); ?>');
                localStorage.setItem('koinnu_auth_active', '1');
            } catch(e) {}
        })();
    </script>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-nu navbar-dark">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                    <i class="fas fa-home mr-1"></i>
                    <?php if(Auth::check() && Auth::user()->isRanting()): ?>
                        Dashboard Ranting
                    <?php elseif(Auth::check() && Auth::user()->isMwc()): ?>
                        Dashboard MWC
                    <?php else: ?>
                        Dashboard PC
                    <?php endif; ?>
                </a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="<?php echo e(route('transactions.create')); ?>" class="nav-link"><i class="fas fa-plus-circle mr-1"></i> Catat Setoran Relawan</a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto align-items-center">
            <?php if(auth()->guard()->check()): ?>
                <!-- User Profile Dropdown Menu (Pojok Kanan Atas) -->
                <li class="nav-item dropdown user-menu mr-2">
                    <a href="#" class="nav-link dropdown-toggle d-flex align-items-center py-1 px-2 text-white" data-toggle="dropdown" aria-expanded="false" style="border-radius: 50px; background: rgba(255, 255, 255, 0.15);">
                        <img src="<?php echo e(Auth::user()->avatar_url); ?>" class="user-image img-circle elevation-1 mr-2" alt="Avatar <?php echo e(Auth::user()->name); ?>" style="width: 28px; height: 28px; object-fit: cover;">
                        <span class="d-none d-md-inline font-weight-bold text-white mr-1 text-truncate" style="max-width: 140px;">
                            <?php echo e(Auth::user()->name); ?>

                        </span>
                        <i class="fas fa-chevron-down text-light small ml-1"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right shadow border-0" style="border-radius: 12px; overflow: hidden; min-width: 240px;">
                        <!-- Header Dropdown Profil -->
                        <li class="p-3 text-center" style="background: linear-gradient(135deg, #0a6b38 0%, #15803d 100%);">
                            <img src="<?php echo e(Auth::user()->avatar_url); ?>" class="img-circle elevation-2 mb-2" alt="Avatar" style="width: 65px; height: 65px; object-fit: cover; border: 3px solid #ffffff;">
                            <p class="mb-1 font-weight-bold text-white text-truncate" style="font-size: 0.95rem;">
                                <?php echo e(Auth::user()->name); ?>

                            </p>
                            <span class="badge badge-warning text-dark font-weight-bold">
                                <?php echo e(Auth::user()->role_display_name); ?>

                            </span>
                        </li>
                        <!-- Item Menu Profil & Password -->
                        <li class="p-2 bg-white">
                            <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item py-2 rounded d-flex align-items-center">
                                <i class="fas fa-user-edit text-success mr-2 fa-fw"></i>
                                <span>Profil Saya</span>
                            </a>
                            <a href="<?php echo e(route('profile.edit')); ?>#card-password" class="dropdown-item py-2 rounded d-flex align-items-center">
                                <i class="fas fa-key text-warning mr-2 fa-fw"></i>
                                <span>Ubah Password</span>
                            </a>
                            <?php if(Auth::user()->isSuperAdmin()): ?>
                                <a href="<?php echo e(route('users.index')); ?>" class="dropdown-item py-2 rounded d-flex align-items-center">
                                    <i class="fas fa-users-cog text-info mr-2 fa-fw"></i>
                                    <span>Manajemen Akun</span>
                                </a>
                            <?php endif; ?>
                            <div class="dropdown-divider my-1"></div>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0 p-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item py-2 rounded text-danger d-flex align-items-center w-100 border-0 bg-transparent text-left">
                                    <i class="fas fa-sign-out-alt mr-2 fa-fw"></i>
                                    <span class="font-weight-bold">Keluar (Logout)</span>
                                </button>
                            </form>
                        </li>
                    </ul>
                </li>
            <?php else: ?>
                <li class="nav-item mr-2">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-xs btn-warning text-dark font-weight-bold">
                        <i class="fas fa-sign-in-alt mr-1"></i>Masuk / Login
                    </a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                    <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-success elevation-4">
        <!-- Brand Logo -->
        <a href="<?php echo e(route('dashboard')); ?>" class="brand-link nu-brand text-center py-2 px-3 d-flex align-items-center justify-content-center" style="background: #ffffff !important; border-bottom: 3px solid var(--nu-green); height: 68px;">
            <img src="<?php echo e(asset('logo_lazisnu_lmg.png')); ?>" alt="NU CARE - LAZISNU PCNU LAMONGAN" style="max-height: 52px; width: auto; object-fit: contain;">
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user panel -->
            <?php
                $currentUser = Auth::user();
            ?>
            <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
                <div class="image">
                    <img src="<?php echo e($currentUser?->avatar_url); ?>" class="img-circle elevation-1" alt="User Image" style="width: 38px; height: 38px; object-fit: cover;">
                </div>
                <div class="info">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="d-block font-weight-bold text-truncate" style="max-width: 160px;" title="Buka Pengaturan Profil Saya">
                        <?php echo e($currentUser?->name ?? 'Pengguna'); ?>

                    </a>
                    <small class="text-success">
                        <i class="fas fa-check-circle mr-1"></i>
                        <?php echo e($currentUser ? $currentUser->role_display_name : 'PC Lazisnu (Cabang)'); ?>

                    </small>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
                    <!-- 1. DASHBOARD -->
                    <?php if(!$currentUser || $currentUser->hasMenuAccess('dashboard')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-tachometer-alt text-warning"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- 2. MASTER DATA (DROPDOWN: MWC, RANTING, RELAWAN, DONATUR) -->
                    <?php if(!$currentUser || $currentUser->hasCategoryAccess('Master Data')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->routeIs(['mwcs.*', 'rantings.*', 'relawans.*', 'donators.*', 'mustahiqs.*']) ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs(['mwcs.*', 'rantings.*', 'relawans.*', 'donators.*', 'mustahiqs.*']) ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-database"></i>
                            <p>
                                Master Data
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!$currentUser || $currentUser->isPc()): ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('mwcs.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('mwcs.index')); ?>" class="nav-link <?php echo e(request()->routeIs('mwcs.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-landmark nav-icon text-info"></i>
                                        <p>MWC</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('rantings.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('rantings.index')); ?>" class="nav-link <?php echo e(request()->routeIs('rantings.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-mosque nav-icon text-success"></i>
                                        <p>Ranting</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                            <?php elseif($currentUser->isMwc()): ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('mwcs.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('mwcs.show', $currentUser->mwc_id)); ?>" class="nav-link <?php echo e(request()->routeIs('mwcs.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-landmark nav-icon text-info"></i>
                                        <p>Data MWC</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('rantings.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('rantings.index')); ?>" class="nav-link <?php echo e(request()->routeIs('rantings.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-mosque nav-icon text-success"></i>
                                        <p>Ranting MWC</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                            <?php elseif($currentUser->isRanting()): ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('rantings.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('rantings.show', $currentUser->ranting_id)); ?>" class="nav-link <?php echo e(request()->routeIs('rantings.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-mosque nav-icon text-success"></i>
                                        <p>Ranting Saya</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if(!$currentUser || $currentUser->hasMenuAccess('relawans.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('relawans.index')); ?>" class="nav-link <?php echo e(request()->routeIs('relawans.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-users nav-icon text-primary"></i>
                                    <p>Relawan</p>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(!$currentUser || $currentUser->hasMenuAccess('donators.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('donators.index')); ?>" class="nav-link <?php echo e(request()->routeIs('donators.index') ? 'active' : ''); ?>">
                                    <i class="fas fa-hand-holding-heart nav-icon text-danger"></i>
                                    <p>Donatur (Kotak)</p>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(!$currentUser || $currentUser->hasMenuAccess('donators.distribution')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('donators.distribution')); ?>" class="nav-link <?php echo e(request()->routeIs('donators.distribution') ? 'active' : ''); ?>">
                                    <i class="fas fa-map-marked-alt nav-icon text-warning"></i>
                                    <p>Pembagian Tugas</p>
                                </a>
                            </li>
                            <?php endif; ?>

                            <?php if(!$currentUser || $currentUser->hasMenuAccess('mustahiqs.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('mustahiqs.index')); ?>" class="nav-link <?php echo e(request()->routeIs('mustahiqs.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-hand-holding-usd nav-icon text-success"></i>
                                    <p>Data Mustahiq</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <!-- 3. TRANSAKSI (DROPDOWN) -->
                    <?php if(!$currentUser || $currentUser->hasCategoryAccess('Transaksi & Operasional')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->routeIs(['transactions.*', 'admin.online-donations.*', 'penthongs.*']) ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs(['transactions.*', 'admin.online-donations.*', 'penthongs.*']) ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-cash-register"></i>
                            <p>
                                Transaksi
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('penthongs.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('penthongs.index')); ?>" class="nav-link <?php echo e(request()->routeIs('penthongs.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-drum nav-icon text-warning"></i>
                                    <p>Periode Penthong</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('transactions.create')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('transactions.create')); ?>" class="nav-link <?php echo e(request()->routeIs('transactions.create') ? 'active' : ''); ?>">
                                    <i class="fas fa-plus-circle nav-icon text-info"></i>
                                    <p>Input Setoran</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('transactions.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('transactions.index')); ?>" class="nav-link <?php echo e(request()->routeIs('transactions.index') ? 'active' : ''); ?>">
                                    <i class="fas fa-coins nav-icon text-success"></i>
                                    <p>Riwayat Setoran</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || ($currentUser->isPc() && $currentUser->hasMenuAccess('admin.online-donations.index'))): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.online-donations.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.online-donations.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-receipt nav-icon text-info"></i>
                                        <p>Donasi Online</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <!-- PENTASYARUFAN (PENGELUARAN DANA & PROKER 5 PILAR) -->
                    <?php if(!$currentUser || $currentUser->hasCategoryAccess('Pentasyarufan & Penyaluran')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->routeIs(['pilar-program.*', 'proker.*', 'pentasyarufan.*', 'bku.*']) ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs(['pilar-program.*', 'proker.*', 'pentasyarufan.*', 'bku.*']) ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-hand-holding-heart text-danger"></i>
                            <p>
                                Pentasyarufan
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('pilar-program.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('pilar-program.index')); ?>" class="nav-link <?php echo e(request()->routeIs('pilar-program.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-shapes nav-icon text-info"></i>
                                    <p>5 Pilar & Pagu</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('proker.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('proker.index')); ?>" class="nav-link <?php echo e(request()->routeIs('proker.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-clipboard-list nav-icon text-warning"></i>
                                    <p>Program Kerja (RAB)</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('pentasyarufan.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('pentasyarufan.index')); ?>" class="nav-link <?php echo e(request()->routeIs(['pentasyarufan.index', 'pentasyarufan.create', 'pentasyarufan.show']) ? 'active' : ''); ?>">
                                    <i class="fas fa-money-bill-wave nav-icon text-success"></i>
                                    <p>Penyaluran & SPJ</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('pentasyarufan.laporan')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('pentasyarufan.laporan')); ?>" class="nav-link <?php echo e(request()->routeIs('pentasyarufan.laporan') ? 'active' : ''); ?>">
                                    <i class="fas fa-file-invoice nav-icon text-primary"></i>
                                    <p>Laporan Penyaluran</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('bku.index')); ?>" class="nav-link <?php echo e(request()->routeIs('bku.*') ? 'active' : ''); ?>">
                                    <i class="fas fa-book nav-icon text-warning"></i>
                                    <p>Buku Kas Umum (BKU)</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <!-- 4. PORTAL PUBLIK (DROPDOWN) -->
                    <?php if(!$currentUser || ($currentUser->isPc() && $currentUser->hasCategoryAccess('Portal Website & Crowdfunding'))): ?>
                        <li class="nav-item has-treeview <?php echo e(request()->routeIs(['admin.categories.*', 'admin.campaigns.*', 'admin.articles.*', 'admin.sliders.*', 'admin.site-settings.*']) ? 'menu-open' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(request()->routeIs(['admin.categories.*', 'admin.campaigns.*', 'admin.articles.*', 'admin.sliders.*', 'admin.site-settings.*']) ? 'active' : ''); ?>">
                                <i class="nav-icon fas fa-globe text-info"></i>
                                <p>
                                    Portal Publik
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('admin.categories.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.categories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-shapes nav-icon text-info"></i>
                                        <p>5 Pilar Program</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('admin.campaigns.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.campaigns.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.campaigns.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-bullhorn nav-icon text-danger"></i>
                                        <p>Kampanye Donasi</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('admin.articles.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.articles.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.articles.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-newspaper nav-icon text-primary"></i>
                                        <p>Berita Penyaluran</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('admin.sliders.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.sliders.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.sliders.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-images nav-icon text-warning"></i>
                                        <p>Banner Slider</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(!$currentUser || $currentUser->hasMenuAccess('admin.site-settings.index')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.site-settings.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.site-settings.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-sliders-h nav-icon text-secondary"></i>
                                        <p>Pengaturan Portal</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <!-- 5. LAPORAN (DROPDOWN - TERBAIK UNTUK KOIN NU) -->
                    <?php if(!$currentUser || $currentUser->hasCategoryAccess('Laporan & Keuangan')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->routeIs(['reports.*', 'admin.financial-reports.*']) ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs(['reports.*', 'admin.financial-reports.*']) ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-chart-line text-warning"></i>
                            <p>
                                Laporan
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('reports.penthong')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.penthong')); ?>" class="nav-link <?php echo e(request()->routeIs(['reports.penthong', 'penthongs.report']) ? 'active' : ''); ?>">
                                    <i class="fas fa-hand-holding-usd nav-icon text-warning"></i>
                                    <p>Bagi Hasil Penthong</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('reports.koin')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.koin')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.koin') ? 'active' : ''); ?>">
                                    <i class="fas fa-chart-pie nav-icon text-success"></i>
                                    <p>Rekap Perolehan</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('reports.wilayah')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.wilayah')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.wilayah') ? 'active' : ''); ?>">
                                    <i class="fas fa-landmark nav-icon text-info"></i>
                                    <p>Capaian MWC & Rtg</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('reports.relawan')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.relawan')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.relawan') ? 'active' : ''); ?>">
                                    <i class="fas fa-user-check nav-icon text-primary"></i>
                                    <p>Kinerja Relawan</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('reports.donatur')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.donatur')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.donatur') ? 'active' : ''); ?>">
                                    <i class="fas fa-boxes nav-icon text-warning"></i>
                                    <p>Distribusi Kotak</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || ($currentUser->isPc() && $currentUser->hasMenuAccess('admin.financial-reports.index'))): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.financial-reports.index')); ?>" class="nav-link <?php echo e(request()->routeIs('admin.financial-reports.*') ? 'active' : ''); ?>">
                                        <i class="fas fa-file-invoice-dollar nav-icon text-danger"></i>
                                        <p>Laporan Audit WTP</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.print')); ?>" target="_blank" class="nav-link">
                                    <i class="fas fa-print nav-icon text-secondary"></i>
                                    <p>Cetak Rekap Resmi</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <!-- 6. PENGATURAN & AKUN (DROPDOWN) -->
                    <?php if(!$currentUser || $currentUser->hasCategoryAccess('Pengaturan Sistem')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->routeIs('users.*') ? 'menu-open' : ''); ?>">
                        <a href="#" class="nav-link <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user-cog"></i>
                            <p>
                                Pengaturan
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('users.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(request()->routeIs('users.index') ? 'active' : ''); ?>">
                                    <i class="fas fa-users-cog nav-icon text-warning"></i>
                                    <p>Manajemen Pengguna</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(auth()->guard()->check()): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('users.edit', Auth::id())); ?>" class="nav-link <?php echo e(request()->routeIs('users.edit') ? 'active' : ''); ?>">
                                        <i class="fas fa-key nav-icon text-info"></i>
                                        <p>Ubah Sandi</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(!$currentUser || $currentUser->hasMenuAccess('buku-panduan')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('buku-panduan')); ?>" target="_blank" class="nav-link">
                                    <i class="fas fa-book-reader nav-icon text-success"></i>
                                    <p>Buku Panduan (PDF)</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <li class="nav-header text-uppercase font-weight-bold text-muted mt-2">Pintasan</li>

                    <!-- 7. LIHAT WEBSITE PUBLIK -->
                    <li class="nav-item">
                        <a href="<?php echo e(route('home')); ?>" target="_blank" class="nav-link text-warning font-weight-bold">
                            <i class="nav-icon fas fa-external-link-alt"></i>
                            <p>Lihat Web Depan</p>
                        </a>
                    </li>

                    <!-- 8. LOGOUT -->
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('logout')); ?>" class="nav-link text-danger font-weight-bold">
                                <i class="nav-icon fas fa-sign-out-alt"></i>
                                <p>Keluar (Logout)</p>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('login')); ?>" class="nav-link text-warning">
                                <i class="nav-icon fas fa-sign-in-alt"></i>
                                <p>Masuk (Login)</p>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-7">
                        <h1 class="m-0 font-weight-bold text-dark"><?php echo $__env->yieldContent('page_title', 'Dashboard PC'); ?></h1>
                    </div>
                    <div class="col-sm-5">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Beranda</a></li>
                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Flash Messages -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                        <h5><i class="icon fas fa-check-circle"></i> Berhasil!</h5>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                        <h5><i class="icon fas fa-ban"></i> Terjadi Kesalahan!</h5>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(session('import_failures')): ?>
                    <div class="alert alert-warning alert-dismissible fade show shadow-sm" role="alert">
                        <h5><i class="icon fas fa-exclamation-triangle"></i> Catatan Import (Dilewati <?php echo e(session('total_failures')); ?> baris):</h5>
                        <p class="mb-1 text-sm">Baris data yang tidak memenuhi validasi/duplikat NIK dilewati secara otomatis:</p>
                        <ul class="mb-0 pl-3 text-sm">
                            <?php $__currentLoopData = session('import_failures'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($fail); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-warning alert-dismissible fade show shadow-sm" role="alert">
                        <h5><i class="icon fas fa-exclamation-circle"></i> Periksa Input:</h5>
                        <ul class="mb-0 pl-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($err); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </div>

    <footer class="main-footer text-sm">
        <strong>Hak Cipta &copy; <?php echo e(date('Y')); ?> <a href="#" class="text-success font-weight-bold">LAZISNU Care</a>.</strong>
        Sistem Manajemen KOIN NU - Hirarki PC, 15 MWC, Ranting & Relawan RT/RW.
        <div class="float-right d-none d-sm-inline-block">
            <b>Versi</b> 2.0.0
        </div>
    </footer>
</div>

<?php if(auth()->guard()->check()): ?>
    <?php if (isset($component)) { $__componentOriginal1dc65c9d80885d4a8142789089540a84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dc65c9d80885d4a8142789089540a84 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-cetak-laporan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-cetak-laporan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dc65c9d80885d4a8142789089540a84)): ?>
<?php $attributes = $__attributesOriginal1dc65c9d80885d4a8142789089540a84; ?>
<?php unset($__attributesOriginal1dc65c9d80885d4a8142789089540a84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dc65c9d80885d4a8142789089540a84)): ?>
<?php $component = $__componentOriginal1dc65c9d80885d4a8142789089540a84; ?>
<?php unset($__componentOriginal1dc65c9d80885d4a8142789089540a84); ?>
<?php endif; ?>
<?php endif; ?>

<!-- SCRIPTS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- FRONTEND ROUTE GUARD & SESSION EXPIRED (HTTP 401) INTERCEPTORS -->
<script>
(function() {
    let isRedirecting = false;

    // 1. Fungsi sentral penanganan Sesi Kadaluarsa / Unauthorized (HTTP 401)
    function triggerSessionExpired(reason) {
        if (isRedirecting) return;
        isRedirecting = true;

        try {
            sessionStorage.removeItem('koinnu_auth_active');
            sessionStorage.removeItem('koinnu_user_id');
            sessionStorage.removeItem('koinnu_user_role');
            localStorage.removeItem('koinnu_auth_active');
        } catch(e) {}

        console.warn('Session expired or unauthorized access detected (HTTP 401):', reason);

        if (window.toastr) {
            toastr.error('Sesi Anda telah habis, silakan login kembali.', 'Sesi Berakhir');
        } else {
            alert('Sesi Anda telah habis, silakan login kembali.');
        }

        window.location.href = "<?php echo e(route('login')); ?>?expired=1";
    }

    // 2. Global Route Guard: Cek auth state sebelum berpindah halaman internal via link click
    document.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (!link || !link.href) return;

        const targetUrl = link.href;
        if (targetUrl.startsWith(window.location.origin) && !targetUrl.includes('#') && !targetUrl.includes('javascript:')) {
            const isAuthActive = sessionStorage.getItem('koinnu_auth_active') || localStorage.getItem('koinnu_auth_active');
            if (!isAuthActive && !targetUrl.includes('/login') && !targetUrl.includes('/quick-login')) {
                e.preventDefault();
                e.stopPropagation();
                triggerSessionExpired('Navigasi dicegah: Client-side auth state tidak ditemukan.');
            }
        }
    }, true);

    // 3. Interceptor Fetch API Global
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        try {
            const response = await originalFetch.apply(this, args);
            if (response && response.status === 401) {
                triggerSessionExpired('Fetch API mengembalikan HTTP 401');
            }
            return response;
        } catch (error) {
            throw error;
        }
    };

    // 4. Interceptor jQuery AJAX Global
    if (window.jQuery) {
        $(document).ajaxError(function(event, jqXHR, settings, thrownError) {
            if (jqXHR && jqXHR.status === 401) {
                triggerSessionExpired('jQuery AJAX mengembalikan HTTP 401');
            }
        });
    }

    // 5. Interceptor XMLHttpRequest Native Global
    const originalXHROpen = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this.addEventListener('load', function() {
            if (this.status === 401) {
                triggerSessionExpired('XMLHttpRequest mengembalikan HTTP 401');
            }
        });
        return originalXHROpen.apply(this, [method, url, ...rest]);
    };

    // 6. Interceptor Axios Global (jika pustaka Axios di-load)
    if (window.axios) {
        window.axios.interceptors.response.use(
            response => response,
            error => {
                if (error.response && error.response.status === 401) {
                    triggerSessionExpired('Axios mengembalikan HTTP 401');
                }
                return Promise.reject(error);
            }
        );
    }
})();
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\koinnu\resources\views/layouts/adminlte.blade.php ENDPATH**/ ?>