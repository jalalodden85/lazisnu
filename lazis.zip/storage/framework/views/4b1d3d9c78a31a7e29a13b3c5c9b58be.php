<?php $__env->startSection('title', 'Laporan Keuangan & Akuntabilitas Publik'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 align-items-center">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark font-weight-bold"><i class="fas fa-file-invoice-dollar text-success mr-2"></i>Laporan Keuangan & Akuntabilitas Publik</h1>
            </div>
            <div class="col-sm-6 text-right">
                <a href="<?php echo e(route('admin.financial-reports.create')); ?>" class="btn btn-success font-weight-bold">
                    <i class="fas fa-plus-circle mr-1"></i> Tambah Laporan Baru
                </a>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle mr-1"></i> <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        <?php endif; ?>

        <div class="card card-outline card-success shadow-sm">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">Daftar Publikasi Laporan Keuangan (Audit WTP & Periodik)</h3>
            </div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Tahun & Periode</th>
                            <th>Judul Laporan</th>
                            <th>Total Pemasukan (Rp)</th>
                            <th>Total Penyaluran (Rp)</th>
                            <th>Status Opini Audit KAP</th>
                            <th>Tanggal Terbit</th>
                            <th style="width: 140px;" class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge badge-success fs-6"><?php echo e($rep->report_year); ?></span>
                                    <div class="small text-muted mt-1"><?php echo e($rep->report_period); ?></div>
                                </td>
                                <td>
                                    <strong><?php echo e($rep->title); ?></strong>
                                    <?php if($rep->file_pdf && $rep->file_pdf !== '#'): ?>
                                        <div class="mt-1">
                                            <a href="<?php echo e($rep->file_pdf); ?>" target="_blank" class="badge badge-danger">
                                                <i class="fas fa-file-pdf mr-1"></i> Berkas PDF
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="text-success font-weight-bold">
                                    Rp <?php echo e(number_format($rep->total_inflow, 0, ',', '.')); ?>

                                </td>
                                <td class="text-danger font-weight-bold">
                                    Rp <?php echo e(number_format($rep->total_outflow, 0, ',', '.')); ?>

                                </td>
                                <td>
                                    <span class="badge badge-warning text-dark font-weight-bold p-1">
                                        <i class="fas fa-award mr-1"></i> <?php echo e($rep->audit_status); ?>

                                    </span>
                                </td>
                                <td><small class="text-muted"><?php echo e($rep->published_at ? $rep->published_at->format('d/m/Y') : '-'); ?></small></td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.financial-reports.edit', $rep->id)); ?>" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.financial-reports.destroy', $rep->id)); ?>" method="POST" onsubmit="return confirm('Hapus laporan keuangan ini?')" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Belum ada laporan keuangan terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($reports->hasPages()): ?>
                <div class="card-footer bg-white">
                    <?php echo e($reports->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\koinnu\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>