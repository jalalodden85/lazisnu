<?php $__env->startSection('title', 'Laporan Distribusi Kotak Koin Donatur'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 align-items-center">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark font-weight-bold"><i class="fas fa-hand-holding-heart text-danger mr-2"></i>Laporan Distribusi Kotak Koin Donatur</h1>
            </div>
            <div class="col-sm-6 text-right">
                <span class="text-muted small">Total Kotak Aktif: <strong class="text-dark fs-5"><?php echo e(number_format($stats['total_kotak'])); ?></strong></span>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <!-- Stat Boxes -->
        <div class="row mb-3">
            <div class="col-md-4">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-primary"><i class="fas fa-boxes"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Total Kotak Terdistribusi</span>
                        <span class="info-box-number"><?php echo e(number_format($stats['total_kotak'])); ?> Kotak</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-success"><i class="fas fa-user-check"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Kotak Berpengampu (Ada Relawan)</span>
                        <span class="info-box-number text-success"><?php echo e(number_format($stats['kotak_assigned'])); ?> Kotak</span>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-box shadow-sm">
                    <span class="info-box-icon bg-warning"><i class="fas fa-user-clock"></i></span>
                    <div class="info-box-content">
                        <span class="info-box-text">Kotak Belum Berpengampu</span>
                        <span class="info-box-number text-warning"><?php echo e(number_format($stats['kotak_unassigned'])); ?> Kotak</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter Card -->
        <div class="card card-outline card-secondary shadow-sm mb-3">
            <div class="card-body p-3">
                <form action="<?php echo e(route('reports.donatur')); ?>" method="GET" class="row g-2 align-items-center">
                    <div class="col-md-4">
                        <select name="mwc_id" class="form-control form-control-sm">
                            <option value="">-- Semua Wilayah MWC --</option>
                            <?php $__currentLoopData = $mwcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mwc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mwc->id); ?>" <?php echo e($mwcId == $mwc->id ? 'selected' : ''); ?>><?php echo e($mwc->code); ?> - <?php echo e($mwc->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select name="status_petugas" class="form-control form-control-sm">
                            <option value="">-- Status Petugas Pengampu --</option>
                            <option value="assigned" <?php echo e(request('status_petugas') == 'assigned' ? 'selected' : ''); ?>>Sudah Ditugaskan ke Relawan</option>
                            <option value="unassigned" <?php echo e(request('status_petugas') == 'unassigned' ? 'selected' : ''); ?>>Belum Memiliki Relawan Pengampu</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-secondary btn-sm btn-block font-weight-bold"><i class="fas fa-filter mr-1"></i> Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card card-outline card-success shadow-sm">
            <div class="card-body p-0 table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Nomor Kotak</th>
                            <th>Nama Donatur</th>
                            <th>No. HP & Alamat</th>
                            <th>Ranting & MWC</th>
                            <th>RT / RW</th>
                            <th>Petugas Relawan Pengampu</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $donators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <span class="badge badge-light border font-weight-bold text-dark fs-6"><?php echo e($don->box_number); ?></span>
                                </td>
                                <td>
                                    <strong><?php echo e($don->name); ?></strong>
                                    <div class="small text-muted">NIK: <?php echo e($don->nik); ?></div>
                                </td>
                                <td>
                                    <div><a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $don->phone)); ?>" target="_blank" class="text-success"><i class="fab fa-whatsapp mr-1"></i><?php echo e($don->phone); ?></a></div>
                                    <small class="text-muted"><?php echo e(Str::limit($don->address, 45)); ?></small>
                                </td>
                                <td>
                                    <span class="badge badge-light border"><?php echo e($don->ranting->name ?? '-'); ?></span>
                                    <div class="small text-muted"><?php echo e($don->ranting->mwc->code ?? ''); ?></div>
                                </td>
                                <td><span class="badge badge-secondary">RT <?php echo e($don->rt); ?> / RW <?php echo e($don->rw); ?></span></td>
                                <td>
                                    <?php if($don->relawan): ?>
                                        <strong class="text-success"><i class="fas fa-user-check mr-1"></i><?php echo e($don->relawan->nama); ?></strong>
                                        <div class="small text-muted">Area: <?php echo e($don->relawan->area_tugas); ?></div>
                                    <?php else: ?>
                                        <span class="badge badge-warning text-dark"><i class="fas fa-exclamation-circle mr-1"></i>Belum Ada Relawan</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge badge-success">Aktif</span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Belum ada donatur terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($donators->hasPages()): ?>
                <div class="card-footer bg-white">
                    <?php echo e($donators->withQueryString()->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\koinnu\resources\views/reports/donatur.blade.php ENDPATH**/ ?>