<?php $__env->startSection('title', 'Detail Ranting - ' . $ranting->code); ?>
<?php $__env->startSection('page_title', 'Ranting: ' . $ranting->name . ' (' . $ranting->code . ')'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('rantings.index')); ?>">Master Ranting</a></li>
    <li class="breadcrumb-item active"><?php echo e($ranting->code); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Profil Ranting -->
    <div class="col-md-4 col-12">
        <div class="card card-outline card-success shadow-sm">
            <div class="card-body box-profile">
                <div class="text-center mb-2">
                    <span class="badge badge-primary px-3 py-2 font-weight-bold" style="font-size: 1.3rem; letter-spacing: 1px;">
                        <?php echo e($ranting->code); ?>

                    </span>
                </div>
                <h3 class="profile-username text-center font-weight-bold text-dark"><?php echo e($ranting->name); ?></h3>
                <p class="text-muted text-center"><i class="fas fa-map-pin mr-1 text-danger"></i> Desa <?php echo e($ranting->desa); ?></p>

                <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item">
                        <b>MWC Induk</b> <span class="float-right font-weight-bold text-success">[<?php echo e($ranting->mwc->code); ?>] <?php echo e($ranting->mwc->name); ?></span>
                    </li>
                    <li class="list-group-item">
                        <b>Total Relawan (RT/RW)</b> <span class="float-right font-weight-bold text-warning"><?php echo e($ranting->relawans->count()); ?> Orang</span>
                    </li>
                    <li class="list-group-item">
                        <b>Total Koin Terkumpul</b> <span class="float-right font-weight-bold text-success">Rp <?php echo e(number_format($totalCollected, 0, ',', '.')); ?></span>
                    </li>
                </ul>

                <a href="<?php echo e(route('relawans.create')); ?>" class="btn btn-success btn-block font-weight-bold shadow-sm mb-2">
                    <i class="fas fa-user-plus mr-1"></i> Tambah Relawan di Ranting Ini
                </a>
                <a href="<?php echo e(route('rantings.edit', $ranting->id)); ?>" class="btn btn-warning text-white btn-block font-weight-bold mb-2">
                    <i class="fas fa-edit mr-1"></i> Edit Data Ranting
                </a>
                <a href="<?php echo e(route('rantings.index')); ?>" class="btn btn-outline-secondary btn-block">
                    <i class="fas fa-arrow-left mr-1"></i> Kembali ke Daftar Ranting
                </a>
            </div>
        </div>
    </div>

    <!-- Daftar Relawan RT/RW pada Ranting ini -->
    <div class="col-md-8 col-12">
        <div class="card shadow-sm">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-users-cog mr-2 text-success"></i> Relawan Koordinator RT/RW pada <?php echo e($ranting->name); ?>

                </h3>
                <span class="badge badge-light border"><?php echo e($ranting->relawans->count()); ?> Relawan</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover m-0 align-middle">
                        <thead class="thead-light">
                            <tr>
                                <th>Nama Relawan</th>
                                <th>NIK</th>
                                <th>Area Tugas (RT/RW)</th>
                                <th>No. HP</th>
                                <th class="text-center">Aksi Setor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ranting->relawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="font-weight-bold text-dark"><?php echo e($relawan->nama); ?></td>
                                    <td><small class="text-muted"><?php echo e($relawan->nik); ?></small></td>
                                    <td><span class="badge badge-light border font-weight-bold"><?php echo e($relawan->area_tugas); ?></span></td>
                                    <td><?php echo e($relawan->no_hp ?? '-'); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('transactions.create', ['relawan_id' => $relawan->id])); ?>" class="btn btn-xs btn-success font-weight-bold">
                                            <i class="fas fa-coins mr-1"></i> Input Setor
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">
                                        Belum ada Relawan terdaftar di Ranting ini. Silakan tambahkan relawan atau gunakan Bulk Import.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\koinnu\resources\views/rantings/show.blade.php ENDPATH**/ ?>