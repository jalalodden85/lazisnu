<?php $__env->startSection('title', 'Laporan Kinerja Relawan Lapangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 align-items-center">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark font-weight-bold"><i class="fas fa-users-cog text-info mr-2"></i>Laporan Kinerja & Aktivitas Relawan</h1>
            </div>
            <div class="col-sm-6 text-right">
                <span class="text-muted small">Periode: <strong><?php echo e($selectedPeriod); ?></strong></span>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <!-- Filter Card -->
        <div class="card card-outline card-info shadow-sm mb-3">
            <div class="card-body p-3">
                <form action="<?php echo e(route('reports.relawan')); ?>" method="GET" class="row g-2 align-items-center">
                    <div class="col-md-3">
                        <label class="small font-weight-bold text-muted mb-1">Periode Bulan:</label>
                        <input type="month" name="period" class="form-control form-control-sm" value="<?php echo e($selectedPeriod); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="small font-weight-bold text-muted mb-1">Filter MWC:</label>
                        <select name="mwc_id" class="form-control form-control-sm">
                            <option value="">-- Semua MWC --</option>
                            <?php $__currentLoopData = $mwcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mwc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mwc->id); ?>" <?php echo e($mwcId == $mwc->id ? 'selected' : ''); ?>><?php echo e($mwc->code); ?> - <?php echo e($mwc->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2 mt-auto">
                        <button type="submit" class="btn btn-info btn-sm btn-block font-weight-bold"><i class="fas fa-filter mr-1"></i> Filter</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card card-outline card-success shadow-sm">
            <div class="card-body p-0 table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>Nama Relawan</th>
                            <th>No. WhatsApp / NIK</th>
                            <th>Ranting & MWC</th>
                            <th>Area Tugas</th>
                            <th class="text-center">Donatur / Kotak Diampu</th>
                            <th class="text-right">Setoran Periode Ini (Rp)</th>
                            <th class="text-right">Total Akumulasi (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $relawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($rel->nama); ?></strong>
                                </td>
                                <td>
                                    <div><a href="https://wa.me/<?php echo e(preg_replace('/[^0-9]/', '', $rel->no_hp)); ?>" target="_blank" class="text-success"><i class="fab fa-whatsapp mr-1"></i><?php echo e($rel->no_hp); ?></a></div>
                                    <small class="text-muted">NIK: <?php echo e($rel->nik); ?></small>
                                </td>
                                <td>
                                    <span class="badge badge-light border"><?php echo e($rel->ranting->name ?? '-'); ?></span>
                                    <div class="small text-muted"><?php echo e($rel->ranting->mwc->code ?? ''); ?> - <?php echo e($rel->ranting->mwc->name ?? ''); ?></div>
                                </td>
                                <td><small class="font-weight-bold"><?php echo e($rel->area_tugas); ?></small></td>
                                <td class="text-center">
                                    <span class="badge badge-primary"><?php echo e($rel->donators_count); ?> Kotak</span>
                                </td>
                                <td class="text-right font-weight-bold text-success fs-6">
                                    Rp <?php echo e(number_format($rel->period_amount, 0, ',', '.')); ?>

                                </td>
                                <td class="text-right font-weight-bold text-dark">
                                    Rp <?php echo e(number_format($rel->total_amount, 0, ',', '.')); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Belum ada data relawan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if($relawans->hasPages()): ?>
                <div class="card-footer bg-white">
                    <?php echo e($relawans->withQueryString()->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlte', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\koinnu\resources\views/reports/relawan.blade.php ENDPATH**/ ?>